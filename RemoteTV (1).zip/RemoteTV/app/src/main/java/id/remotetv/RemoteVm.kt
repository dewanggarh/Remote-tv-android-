package id.remotetv

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface UiState {
    data object Pick : UiState
    data class Connecting(val d: TvDevice) : UiState
    data class NeedCode(val d: TvDevice) : UiState
    data class Remote(val d: TvDevice) : UiState
}

sealed interface Step {
    data class Key(val code: Int, val times: Int = 1) : Step
    data class App(val link: String) : Step
    data class Wait(val ms: Long) : Step
}

data class Macro(val name: String, val steps: List<Step>)

val APPS = listOf(
    "YouTube" to "https://www.youtube.com",
    "Netflix" to "https://www.netflix.com",
    "Prime Video" to "https://app.primevideo.com",
    "Disney+" to "https://www.disneyplus.com"
)

val MACROS = listOf(
    Macro("Mode malam", listOf(Step.Key(Keys.VOL_DOWN, 8))),
    Macro("Buka YouTube", listOf(Step.Key(Keys.HOME), Step.Wait(800), Step.App(APPS[0].second))),
    Macro("Netflix santai", listOf(Step.App(APPS[1].second), Step.Wait(4000), Step.Key(Keys.CENTER)))
)

class RemoteVm(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("tv", 0)
    val devices = MutableStateFlow<List<TvDevice>>(emptyList())
    val state = MutableStateFlow<UiState>(UiState.Pick)
    val message = MutableStateFlow<String?>(null)
    private var client: RemoteClient? = null
    private var pairing: PairingClient? = null
    private val discovery = Discovery(app) { d -> devices.update { l -> if (l.any { it.host == d.host }) l else l + d } }

    init {
        Tls.dir = app.filesDir
        discovery.start()
        prefs.getString("last", null)?.split("|", limit = 2)?.takeIf { it.size == 2 }
            ?.let { connect(TvDevice(it[1], it[0])) }
    }

    fun connect(d: TvDevice) {
        state.value = UiState.Connecting(d)
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val c = RemoteClient(d.host, getApplication<Application>().packageName) {
                    if (state.value is UiState.Remote) {
                        message.value = "Koneksi terputus"
                        state.value = UiState.Pick
                    }
                }
                c.connect()
                client = c
                prefs.edit().putString("last", "${d.host}|${d.name}").apply()
                state.value = UiState.Remote(d)
            } catch (e: Exception) {
                beginPairing(d) // kemungkinan besar belum dipasangkan
            }
        }
    }

    private fun beginPairing(d: TvDevice) {
        try {
            val p = PairingClient(d.host)
            p.begin()
            pairing = p
            state.value = UiState.NeedCode(d)
        } catch (e: Exception) {
            message.value = "Gagal terhubung ke TV: ${e.message}"
            state.value = UiState.Pick
        }
    }

    fun submitCode(code: String) {
        val d = (state.value as? UiState.NeedCode)?.d ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                pairing?.finish(code)
                pairing = null
                connect(d)
            } catch (e: Exception) {
                message.value = e.message ?: "Kode salah"
            }
        }
    }

    fun cancelPairing() { pairing?.close(); pairing = null; state.value = UiState.Pick }

    fun disconnect() {
        client?.close(); client = null
        prefs.edit().remove("last").apply()
        state.value = UiState.Pick
    }

    fun press(code: Int) { viewModelScope.launch(Dispatchers.IO) { runCatching { client?.key(code) } } }
    fun openApp(link: String) { viewModelScope.launch(Dispatchers.IO) { runCatching { client?.launch(link) } } }

    fun type(text: String) {
        viewModelScope.launch(Dispatchers.IO) {
            text.lowercase().forEach { ch ->
                Keys.fromChar(ch)?.let { runCatching { client?.key(it) }; delay(35) }
            }
        }
    }

    /** Hasil suara: buka pencarian TV, ketik, lalu Enter. */
    fun search(text: String) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { client?.key(Keys.SEARCH) }
            delay(1500)
            text.lowercase().forEach { ch -> Keys.fromChar(ch)?.let { runCatching { client?.key(it) }; delay(35) } }
            runCatching { client?.key(Keys.ENTER) }
        }
    }

    fun run(m: Macro) {
        viewModelScope.launch(Dispatchers.IO) {
            for (s in m.steps) runCatching {
                when (s) {
                    is Step.Key -> repeat(s.times) { client?.key(s.code); delay(120) }
                    is Step.App -> client?.launch(s.link)
                    is Step.Wait -> delay(s.ms)
                }
            }
        }
    }

    override fun onCleared() { discovery.stop(); client?.close(); pairing?.close() }
}
