package id.remotetv

import android.annotation.SuppressLint
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.File
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.X509TrustManager

/**
 * Identitas klien (kunci RSA + sertifikat self-signed) dibuat sekali di software
 * dan disimpan di folder privat aplikasi. TV memakainya untuk mengenali HP ini.
 */
object Tls {
    lateinit var dir: File
    private var cached: Pair<PrivateKey, X509Certificate>? = null

    @Synchronized
    private fun identity(): Pair<PrivateKey, X509Certificate> {
        cached?.let { return it }
        val kf = File(dir, "client.key")
        val cf = File(dir, "client.crt")
        val key: PrivateKey
        val cert: X509Certificate
        if (kf.exists() && cf.exists()) {
            key = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(kf.readBytes()))
            cert = CertificateFactory.getInstance("X.509").generateCertificate(cf.inputStream()) as X509Certificate
        } else {
            val kp = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
            val name = X500Name("CN=remote-hp")
            val now = System.currentTimeMillis()
            val day = 86_400_000L
            val holder = JcaX509v3CertificateBuilder(
                name, BigInteger.valueOf(now), Date(now - day), Date(now + 3650L * day), name, kp.public
            ).build(JcaContentSignerBuilder("SHA256withRSA").build(kp.private))
            cert = JcaX509CertificateConverter().getCertificate(holder)
            key = kp.private
            kf.writeBytes(key.encoded)
            cf.writeBytes(cert.encoded)
        }
        return (key to cert).also { cached = it }
    }

    fun clientCert(): X509Certificate = identity().second

    /** TV memakai sertifikat self-signed, jadi sertifikat server tidak divalidasi (hanya untuk LAN). */
    @SuppressLint("CustomX509TrustManager", "TrustAllX509TrustManager")
    fun socketFactory(): SSLSocketFactory {
        val (key, cert) = identity()
        val ks = KeyStore.getInstance(KeyStore.getDefaultType()).apply {
            load(null, null)
            setKeyEntry("client", key, CharArray(0), arrayOf(cert))
        }
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
            .apply { init(ks, CharArray(0)) }
        val trustAll = object : X509TrustManager {
            override fun checkClientTrusted(c: Array<X509Certificate>?, a: String?) {}
            override fun checkServerTrusted(c: Array<X509Certificate>?, a: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        }
        return SSLContext.getInstance("TLS").apply { init(kmf.keyManagers, arrayOf(trustAll), null) }.socketFactory
    }
}
