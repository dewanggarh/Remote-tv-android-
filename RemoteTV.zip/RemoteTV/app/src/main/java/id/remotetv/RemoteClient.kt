package id.remotetv

import java.net.InetSocketAddress
import javax.net.ssl.SSLSocket
import kotlin.concurrent.thread

/** Koneksi remote (port 6466) setelah pairing. */
class RemoteClient(
    private val host: String,
    private val pkg: String,
    private val onDrop: () -> Unit
) {
    private var sock: SSLSocket? = null
    @Volatile private var closing = false
    @Volatile private var active = false
    private val lock = Any()

    /** Blocking. Melempar exception bila handshake gagal (mis. belum dipasangkan). */
    fun connect() {
        val s = Tls.socketFactory().createSocket() as SSLSocket
        s.connect(InetSocketAddress(host, 6466), 5000)
        s.soTimeout = 8000
        s.startHandshake()
        sock = s
        while (!active) handle(PbR(s.inputStream.readFrame()))
        s.soTimeout = 0
        thread(isDaemon = true) {
            try { while (!closing) handle(PbR(s.inputStream.readFrame())) } catch (_: Exception) {}
            if (!closing) onDrop()
        }
    }

    private fun handle(m: PbR) {
        when {
            m.has(1) -> send(
                PbW().msg(1, PbW().int(1, 622).msg(
                    2, PbW().str(1, "Remote HP").str(2, "Android").int(3, 1).str(4, "1").str(5, pkg).str(6, "1.0.0")
                )).build()
            )
            m.has(2) -> { send(PbW().msg(2, PbW().int(1, 622)).build()); active = true }
            m.has(8) -> send(PbW().msg(9, PbW().int(1, m.msg(8)?.int(1) ?: 0)).build())
        }
    }

    private fun send(b: ByteArray) = synchronized(lock) { sock?.outputStream?.writeFrame(b) }

    /** direction: 3 = tekan singkat, 1 = mulai tahan, 2 = lepas. */
    fun key(code: Int, direction: Int = 3) = send(PbW().msg(10, PbW().int(1, code).int(2, direction)).build())

    fun launch(link: String) = send(PbW().msg(90, PbW().str(1, link)).build())

    fun close() { closing = true; runCatching { sock?.close() } }
}
