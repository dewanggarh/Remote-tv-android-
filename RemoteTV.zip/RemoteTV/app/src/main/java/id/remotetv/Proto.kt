package id.remotetv

import java.io.ByteArrayOutputStream
import java.io.EOFException
import java.io.InputStream
import java.io.OutputStream

/** Penulis protobuf mini (varint + length-delimited). */
class PbW {
    private val o = ByteArrayOutputStream()
    private fun v(x: Long) {
        var n = x
        while ((n and 127L.inv()) != 0L) { o.write(((n and 127L) or 128L).toInt()); n = n ushr 7 }
        o.write(n.toInt())
    }
    fun int(f: Int, x: Int) = apply { v((f shl 3).toLong()); v(x.toLong()) }
    fun bytes(f: Int, b: ByteArray) = apply { v(((f shl 3) or 2).toLong()); v(b.size.toLong()); o.write(b) }
    fun str(f: Int, s: String) = bytes(f, s.toByteArray())
    fun msg(f: Int, m: PbW) = bytes(f, m.build())
    fun build(): ByteArray = o.toByteArray()
}

/** Pembaca protobuf mini: hanya menyimpan nilai terakhir tiap field. */
class PbR(d: ByteArray) {
    private val m = HashMap<Int, Any>()
    init {
        var p = 0
        fun rv(): Long {
            var r = 0L; var s = 0
            while (true) {
                val b = d[p++].toInt()
                r = r or ((b and 127).toLong() shl s)
                if ((b and 128) == 0) break
                s += 7
            }
            return r
        }
        while (p < d.size) {
            val t = rv().toInt()
            val f = t shr 3
            when (t and 7) {
                0 -> m[f] = rv()
                2 -> { val l = rv().toInt(); m[f] = d.copyOfRange(p, p + l); p += l }
                1 -> p += 8
                5 -> p += 4
                else -> break
            }
        }
    }
    fun has(f: Int) = m.containsKey(f)
    fun int(f: Int): Int = (m[f] as? Long)?.toInt() ?: 0
    fun msg(f: Int): PbR? = (m[f] as? ByteArray)?.let { PbR(it) }
}

fun InputStream.readVarint(): Int {
    var r = 0; var s = 0
    while (true) {
        val b = read()
        if (b < 0) throw EOFException()
        r = r or ((b and 127) shl s)
        if ((b and 128) == 0) return r
        s += 7
    }
}

fun InputStream.readFrame(): ByteArray {
    val n = readVarint()
    val buf = ByteArray(n)
    var o = 0
    while (o < n) {
        val k = read(buf, o, n - o)
        if (k < 0) throw EOFException()
        o += k
    }
    return buf
}

fun OutputStream.writeFrame(b: ByteArray) {
    val h = ByteArrayOutputStream()
    var n = b.size
    while (n > 127) { h.write((n and 127) or 128); n = n ushr 7 }
    h.write(n)
    write(h.toByteArray()); write(b); flush()
}
