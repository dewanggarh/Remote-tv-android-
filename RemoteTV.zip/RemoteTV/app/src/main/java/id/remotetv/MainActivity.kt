package id.remotetv

import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    private val vm: RemoteVm by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { App(vm) } }
    }

    // Tombol volume fisik HP mengatur volume TV saat remote aktif.
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (vm.state.value is UiState.Remote &&
            (e.keyCode == KeyEvent.KEYCODE_VOLUME_UP || e.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)
        ) {
            if (e.action == KeyEvent.ACTION_DOWN)
                vm.press(if (e.keyCode == KeyEvent.KEYCODE_VOLUME_UP) Keys.VOL_UP else Keys.VOL_DOWN)
            return true
        }
        return super.dispatchKeyEvent(e)
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val scheme = if (Build.VERSION.SDK_INT >= 31) dynamicDarkColorScheme(ctx) else darkColorScheme()
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun App(vm: RemoteVm) {
    val st by vm.state.collectAsStateWithLifecycle()
    val msg by vm.message.collectAsStateWithLifecycle()
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(msg) { msg?.let { snack.showSnackbar(it); vm.message.value = null } }
    Scaffold(snackbarHost = { SnackbarHost(snack) }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (val s = st) {
                is UiState.Pick -> PickScreen(vm)
                is UiState.Connecting -> Column(
                    Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally
                ) { CircularProgressIndicator(); Spacer(Modifier.height(16.dp)); Text("Menghubungkan ke ${s.d.name}…") }
                is UiState.NeedCode -> CodeScreen(vm, s.d)
                is UiState.Remote -> RemoteScreen(vm, s.d)
            }
        }
    }
}

@Composable
fun PickScreen(vm: RemoteVm) {
    val devices by vm.devices.collectAsStateWithLifecycle()
    var ip by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Remote TV", style = MaterialTheme.typography.headlineMedium)
        Text("Pastikan HP dan TV di Wi-Fi yang sama.", style = MaterialTheme.typography.bodyMedium)
        if (devices.isEmpty()) Text("Mencari TV…", color = MaterialTheme.colorScheme.primary)
        devices.forEach { d ->
            Card(Modifier.fillMaxWidth().clickable { vm.connect(d) }) {
                Column(Modifier.padding(16.dp)) {
                    Text(d.name, style = MaterialTheme.typography.titleMedium)
                    Text(d.host, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        HorizontalDivider()
        Text("Atau masukkan IP TV manual")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(ip, { ip = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("192.168.1.20") })
            Button(onClick = { if (ip.isNotBlank()) vm.connect(TvDevice("TV $ip", ip.trim())) }) { Text("Hubungkan") }
        }
    }
}

@Composable
fun CodeScreen(vm: RemoteVm, d: TvDevice) {
    var code by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("Pairing dengan ${d.name}", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text("Masukkan kode 6 karakter yang tampil di layar TV.")
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            code, { code = it.uppercase().take(6) }, singleLine = true,
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(capitalization = KeyboardCapitalization.Characters)
        )
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            TextButton(onClick = { vm.cancelPairing() }) { Text("Batal") }
            Button(onClick = { vm.submitCode(code) }, enabled = code.length == 6) { Text("Pasangkan") }
        }
    }
}

@Composable
fun RemoteScreen(vm: RemoteVm, d: TvDevice) {
    val hap = LocalHapticFeedback.current
    val ctx = LocalContext.current
    fun k(c: Int) { hap.performHapticFeedback(HapticFeedbackType.TextHandleMove); vm.press(c) }
    var text by remember { mutableStateOf("") }

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { vm.search(it) }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(d.name, style = MaterialTheme.typography.titleMedium)
                Text("Terhubung", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
            }
            IconButton({ vm.disconnect() }) { Icon(Icons.Default.LinkOff, "Putuskan") }
            FilledIconButton(
                { k(Keys.POWER) },
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = MaterialTheme.colorScheme.error)
            ) { Icon(Icons.Default.PowerSettingsNew, "Power") }
        }

        Touchpad(onDir = { k(it) }, onTap = { k(Keys.CENTER) }, onBack = { k(Keys.BACK) })

        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Pad(Icons.Default.KeyboardArrowUp, "Atas") { k(Keys.UP) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Pad(Icons.Default.KeyboardArrowLeft, "Kiri") { k(Keys.LEFT) }
                Button({ k(Keys.CENTER) }, Modifier.size(72.dp), shape = CircleShape) { Text("OK") }
                Pad(Icons.Default.KeyboardArrowRight, "Kanan") { k(Keys.RIGHT) }
            }
            Pad(Icons.Default.KeyboardArrowDown, "Bawah") { k(Keys.DOWN) }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Pad(Icons.Default.ArrowBack, "Kembali") { k(Keys.BACK) }
            Pad(Icons.Default.Home, "Home") { k(Keys.HOME) }
            Pad(Icons.Default.Menu, "Menu") { k(Keys.MENU) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Pad(Icons.Default.VolumeDown, "Volume -") { k(Keys.VOL_DOWN) }
            Pad(Icons.Default.VolumeOff, "Mute") { k(Keys.MUTE) }
            Pad(Icons.Default.VolumeUp, "Volume +") { k(Keys.VOL_UP) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Pad(Icons.Default.SkipPrevious, "Sebelumnya") { k(Keys.PREV) }
            Pad(Icons.Default.PlayArrow, "Putar/Jeda") { k(Keys.PLAY_PAUSE) }
            Pad(Icons.Default.SkipNext, "Berikutnya") { k(Keys.NEXT) }
        }

        Text("Aplikasi", Modifier.fillMaxWidth(), style = MaterialTheme.typography.labelLarge)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            APPS.forEach { (n, link) -> AssistChip(onClick = { vm.openApp(link) }, label = { Text(n) }) }
        }

        Text("Makro", Modifier.fillMaxWidth(), style = MaterialTheme.typography.labelLarge)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MACROS.forEach { m -> SuggestionChip(onClick = { vm.run(m) }, label = { Text(m.name) }) }
        }

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                text, { text = it }, Modifier.weight(1f), singleLine = true,
                placeholder = { Text("Ketik di TV") }
            )
            IconButton({ vm.type(text); text = "" }) { Icon(Icons.Default.Send, "Kirim") }
            IconButton({
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
                try { speech.launch(i) } catch (_: ActivityNotFoundException) { vm.message.value = "Pengenal suara tidak tersedia" }
            }) { Icon(Icons.Default.Mic, "Cari dengan suara") }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun Pad(icon: ImageVector, desc: String, onClick: () -> Unit) =
    FilledTonalIconButton(onClick, Modifier.size(64.dp)) { Icon(icon, desc, Modifier.size(30.dp)) }

@Composable
fun Touchpad(onDir: (Int) -> Unit, onTap: () -> Unit, onBack: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(24.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .pointerInput(Unit) { detectTapGestures(onTap = { onTap() }, onDoubleTap = { onBack() }) }
            .pointerInput(Unit) {
                var ax = 0f; var ay = 0f
                detectDragGestures(onDragStart = { ax = 0f; ay = 0f }) { change, d ->
                    change.consume(); ax += d.x; ay += d.y
                    if (abs(ax) > 70f || abs(ay) > 70f) {
                        onDir(
                            if (abs(ax) > abs(ay)) (if (ax > 0) Keys.RIGHT else Keys.LEFT)
                            else (if (ay > 0) Keys.DOWN else Keys.UP)
                        )
                        ax = 0f; ay = 0f
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            "Geser = navigasi\nKetuk = OK · Ketuk 2× = Kembali",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodySmall
        )
    }
}
