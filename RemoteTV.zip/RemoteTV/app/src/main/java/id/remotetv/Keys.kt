package id.remotetv

/** Kode tombol Android (KeyEvent). */
object Keys {
    const val HOME = 3; const val BACK = 4; const val SEARCH = 84; const val MENU = 82
    const val UP = 19; const val DOWN = 20; const val LEFT = 21; const val RIGHT = 22; const val CENTER = 23
    const val VOL_UP = 24; const val VOL_DOWN = 25; const val POWER = 26; const val MUTE = 164
    const val PLAY_PAUSE = 85; const val NEXT = 87; const val PREV = 88
    const val ENTER = 66; const val DEL = 67; const val SPACE = 62

    fun fromChar(c: Char): Int? = when (c) {
        in 'a'..'z' -> 29 + (c - 'a')
        in '0'..'9' -> 7 + (c - '0')
        ' ' -> SPACE; '.' -> 56; ',' -> 55; '-' -> 69; '/' -> 76; '@' -> 77
        '\n' -> ENTER
        else -> null
    }
}
