package id.remotetv

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo

data class TvDevice(val name: String, val host: String)

/** Mencari TV Android di jaringan Wi-Fi lewat mDNS (_androidtvremote2._tcp). */
class Discovery(ctx: Context, private val onFound: (TvDevice) -> Unit) {
    private val nsd = ctx.getSystemService(NsdManager::class.java)
    private val queue = ArrayDeque<NsdServiceInfo>()
    private var busy = false

    private val listener = object : NsdManager.DiscoveryListener {
        override fun onServiceFound(i: NsdServiceInfo) { synchronized(this@Discovery) { queue.add(i) }; next() }
        override fun onStartDiscoveryFailed(t: String?, e: Int) {}
        override fun onStopDiscoveryFailed(t: String?, e: Int) {}
        override fun onDiscoveryStarted(t: String?) {}
        override fun onDiscoveryStopped(t: String?) {}
        override fun onServiceLost(i: NsdServiceInfo) {}
    }

    @Synchronized private fun next() {
        if (busy) return
        val i = queue.removeFirstOrNull() ?: return
        busy = true
        nsd.resolveService(i, object : NsdManager.ResolveListener {
            override fun onResolveFailed(s: NsdServiceInfo?, e: Int) = done()
            override fun onServiceResolved(s: NsdServiceInfo) {
                val ip = s.host?.hostAddress
                if (ip != null && !ip.contains(':')) onFound(TvDevice(s.serviceName, ip))
                done()
            }
        })
    }

    @Synchronized private fun done() { busy = false; next() }

    fun start() = runCatching { nsd.discoverServices("_androidtvremote2._tcp.", NsdManager.PROTOCOL_DNS_SD, listener) }
    fun stop() = runCatching { nsd.stopServiceDiscovery(listener) }
}
