package id.remotetv

import java.io.IOException
import java.math.BigInteger
import java.net.InetSocketAddress
import java.security.MessageDigest
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPublicKey
import javax.net.ssl.SSLSocket

/** Pairing (port 6467): TV menampilkan kode 6 karakter hex, kita kirim hash rahasianya. */
class PairingClient(private val host: String) {
    private var sock: SSLSocket? = null
    private lateinit var serverCert: X509Certificate

    private fun pm(status: Int = 200, build: PbW.() -> Unit) =
        PbW().int(1, 2).int(2, status).apply(build).build()

    private fun enc() = PbW().int(1, 3).int(2, 6) // HEXADECIMAL, 6 simbol

    private fun expect(frame: ByteArray) {
        if (PbR(frame).int(2) != 200) throw IOException("Pairing ditolak TV")
    }

    /** Blocking: jalankan di thread IO. Setelah selesai, kode muncul di layar TV. */
    fun begin() {
        val s = Tls.socketFactory().createSocket() as SSLSocket
        s.connect(InetSocketAddress(host, 6467), 5000)
        s.soTimeout = 10000
        s.startHandshake()
        serverCert = s.session.peerCertificates[0] as X509Certificate
        sock = s
        val i = s.inputStream; val o = s.outputStream
        o.writeFrame(pm { msg(10, PbW().str(1, "atvremote").str(2, "Remote HP")) }); expect(i.readFrame())
        o.writeFrame(pm { msg(20, PbW().msg(1, enc()).int(3, 1)) }); expect(i.readFrame())
        o.writeFrame(pm { msg(30, PbW().msg(1, enc()).int(2, 1)) }); expect(i.readFrame())
        s.soTimeout = 0
    }

    private fun strip(b: BigInteger): ByteArray =
        b.toByteArray().let { if (it.size > 1 && it[0] == 0.toByte()) it.copyOfRange(1, it.size) else it }

    fun finish(code: String) {
        val c = code.trim().uppercase()
        if (c.length != 6 || !c.all { it in "0123456789ABCDEF" }) throw IOException("Kode harus 6 karakter (0-9, A-F)")
        val cb = c.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
        val cp = Tls.clientCert().publicKey as RSAPublicKey
        val sp = serverCert.publicKey as RSAPublicKey
        val h = MessageDigest.getInstance("SHA-256").apply {
            update(strip(cp.modulus)); update(strip(cp.publicExponent))
            update(strip(sp.modulus)); update(strip(sp.publicExponent))
            update(cb, 1, 2)
        }.digest()
        if (h[0] != cb[0]) throw IOException("Kode salah, coba lagi")
        val s = sock ?: throw IOException("Sesi pairing habis")
        s.outputStream.writeFrame(pm { msg(40, PbW().bytes(1, h)) })
        expect(s.inputStream.readFrame())
        close()
    }

    fun close() { runCatching { sock?.close() }; sock = null }
}
