# Remote TV (Android TV Remote Protocol v2)

1. Buka folder ini di Android Studio (Koala / 2024.1+), tunggu Gradle sync.
2. Colok HP (USB debugging) lalu Run, atau Build > Build APK.
3. HP & TV harus di Wi-Fi yang sama. Buka app, pilih TV, masukkan kode 6 karakter dari layar TV.

Fitur: auto-discover TV, pairing, touchpad, D-pad, volume (termasuk tombol fisik HP),
media, power, peluncur aplikasi, keyboard, pencarian suara, makro.
